package service;

public class ControleVacinasException extends Exception {
    public ControleVacinasException(String message) {
        super(message);
    }
}
